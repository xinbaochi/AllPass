<!DOCTYPE html>

<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>歐趴歐趴</title>
</head>

<body>

<div id="Header">
	<a href="index.php"><img src="allPass.jpg"></a>
	歐趴歐趴
	<input id="search-box" type="text" name="search-box" value="搜尋課程" />
</div>
<div id="body">
<input type="button" value="思維方法" onclick="location.href='thinklist.php'" style="width:120px;height:40px;font-size:20px;">
<input type="button" value="美學素養" onclick="location.href='beautylist.php'" style="width:120px;height:40px;font-size:20px;"><br>
<input type="button" value="公民素養" onclick="location.href='peoplelist.php'" style="width:120px;height:40px;font-size:20px;">
<input type="button" value="文化素養" onclick="location.href='cluturelist.php'" style="width:120px;height:40px;font-size:20px;"><br>
<input type="button" value="科學素養" onclick="location.href='scienselist.php'" style="width:120px;height:40px;font-size:20px;">
<input type="button" value="倫理素養" onclick="location.href='mindlist.php'" style="width:120px;height:40px;font-size:20px;"><br>
</div>	

</body>
</html>