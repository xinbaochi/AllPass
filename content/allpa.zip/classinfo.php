<!DOCTYPE html>

<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>歐趴歐趴</title>
</head>

<body>

<div id="Header">
	<a href="index.php"><img src="allPass.jpg"></a>
	歐趴歐趴
	<input id="search-box" type="text" name="search-box" value="搜尋課程" />
</div>
<div >
科普讀物導讀 <img src="like.jpg"> <img src="dislike.jpg"><br>
<HR width="20%"  align="left">
課程編號：C512<br>
學分數：3<br>
上課時間：2,3,4 二<br>
課程分類：科學素養-科學素養<br>
授課教師：胡忠信<br>
授課語言主要語言：國語<br>
次要語言：--<br>
</div>	
<div>
	<table border="1">
　<tr>
　<td>評論</td>
  <td>Q&A</td>
  <td>下載</td>
　</tr>
</table>
</div>
<div>
	<table border="2">
　<tr>
　		<td>
		c8763<br>
	  	沒再點名的<br>
		檢舉
		</td>
  </tr>
  <tr>
  		<td>
  		starbust<br>
	  	老詩人很好<br>
		檢舉
		</td>
  </tr>
  <tr>
  	<td>
  		c8763<br>
	  	作業很少<br>
		檢舉
	</td>
　</tr>
</table>
</div>
</body>
</html>