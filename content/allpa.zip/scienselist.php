<!DOCTYPE html>

<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>歐趴歐趴</title>
</head>

<body>

<div id="Header">
	<a href="index.php"><img src="allPass.jpg"></a>
	歐趴歐趴
	<input id="search-box" type="text" name="search-box" value="搜尋課程" />
</div>
<div id="body">
<a href="classinfo.php">科普讀物導讀</a> 胡忠信 <img src="like.jpg"><br>
<a href="classinfo.php">科普讀物導讀</a> 洪鼎惟 <img src="dislike.jpg">
</div>	

</body>
</html>