<!DOCTYPE html>

<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>歐趴歐趴</title>
</head>

<body>

<div id="Header">
	<a href="index.php"><img src="allPass.jpg"></a>
	歐趴歐趴
	<input id="search-box" type="text" name="search-box" value="搜尋課程" />
</div>
<div id="body">
<input type="button" value="核心通識" onclick="location.href='coreclass.php'" style="width:120px;height:40px;font-size:20px;">
<input type="button" value="博雅通識" onclick="location.href='boyaclass.php'" style="width:120px;height:40px;font-size:20px;">
</div>	

</body>
</html>