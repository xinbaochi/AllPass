<!DOCTYPE html>

<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>歐趴歐趴</title>
</head>

<body>

<div id="Header">
	<a href="index.php"><img src="allPass.jpg"></a>
	歐趴歐趴
	<input id="search-box" type="text" name="search-box" value="搜尋課程" />
</div>
<div id="body">
<input type="button" value="人文科學" onclick="location.href='humanlist.php'"style="width:120px;height:40px;font-size:20px;"><br>
<input type="button" value="社會科學" style="width:120px;height:40px;font-size:20px;"><br>
<input type="button" value="自然科學" style="width:120px;height:40px;font-size:20px;"><br>
</div>	

</body>
</html>